let value=0;
let Y= 1215;
function setup() {
  createCanvas(1215,1215);
  background(180);
  colorMode(RGB,255,255,255,1);

frameRate(60)
}
function draw() {
	
Y=Y-5;
if (Y<0){
	Y=height;
}
for(var F=30;F>256; f-=2)
strokeWeight(F);
 stroke(F+7,237,95,1);
fill(105,37,200,.7);
if (keyIsPressed===true){
fill(290,37,85,.4);	
}
ellipse(505,Y,100,100);
strokeWeight(7);
stroke(108,205,35,1);
fill(value,200,150,.5);
triangle(555,796,800,500,400,350);
if (keyIsPressed===true){ 
rect(55,55,100,100)	
}
	
}
function mouseClicked(){
if (value===0){
	value=235; 
} else {value=0;
}

}