function setup() {
createCanvas(900,900);
colorMode( RGB,255,255,255,1);
background(3);


}

function draw() {
stroke(201,39,110,0.7);	
 strokeWeight(8);
fill(120,90,150,0.9);
triangle(90, 175, 88, 70, 186, 175);
 
 noStroke()
 fill(35,90,220,0.3);
 arc(355,355,100,100,0, PI, OPEN);

 stroke(2,39,105,0.2);
 strokeWeight(10);

 stroke(2,39,105,0.2);
 strokeWeight(5);
fill(19,99,87,1);
 quad(338,331,286,220,269,263,230,276);

stroke(200,85,105,0.7);
strokeWeight(9);
point(450,480);
point(575,570);
point(725,750);
point(550,850);
point(350,650);

stroke(230,255,195,.4)
strokeWeight(4);
noFill();
beginShape();
curveVertex(450,480);
curveVertex(450,480);
curveVertex(575,570);
curveVertex(725,750);
curveVertex(550,850);
curveVertex(350,650);
curveVertex(350,650);
endShape()
}