function setup() {
createCanvas(1900,1200);
colorMode(RGB,245,245,245,1);
background(230);
frameRate(30);


}





function draw() {
pie=new PIEMAN(width/3,height/3,20);//this is here because it comes up undefined in the setup
pie.move();
pie.display();
 strokeWeight(1);
 stroke(1);
 fill(149,75,12,1);
 rect(0,1100,1900,100);

 push();
 strokeWeight(1);
 stroke(2);
 fill(255,217,135,1);
 rect(300,790,250,60);
 square (400,600,45);
 pop();

 rect(1100,1050,400,50);
 rect(1150,1000,350,50);
 rect(1200,950,300,50);
 rect(1250,900,250,50);
 rect(1300,850,200,50);
 rect(1350,800,150,50);
 rect(1400,750,100,50);
 rect(1450,700,50,50);
fill(255,217,135,1);
 square(1750,1040,60);
 push();
 stroke(0,225,0,1);
 strokeWeight(3);
 line(1780,1038,1780,550);
 
fill(0,235,0,1);
circle(1780,545,15);
fill(255);
triangle(1780,550,1850,610,1780,650);
pop();

function PIEMAN(tempX,tempY,size){
push();
this.x= tempX;
this.y =tempY;
this.diameter=size;
this.speed=3.1;
this.move =function(){
this.x=random(-this.speed,this.speed);
this.y=random(-this.speed,this.speed);	

}


this.display=function(){

strokeWeight(2);
stroke(0);
fill(71,39,11,1);
translate(-15,-35);
arc (this.x,this.y,this.diameter,this.diameter,PI+QUARTER_PI,PIE);	



}
pop()
  }
for (var d = 100; d < width-980; d += 60) {
  	print('the value of d is');
  block(d, 40, d + 60, 80);
  }
}



function block(x,y){
push();
translate(x,y);
strokeWeight(2);
stroke(35,35,35,1);
fill(35,35,35,1);  
square(50,970,50);
line(65,1100,65,1000); 


	
pop();
}






